package banking.domain;

public class Account {
	protected String accountNum;
	protected static double balance;
	
	public void deposite(double amount) {
		System.out.println("입금 전 금액 : " + balance + "원");
		this.balance += amount;
		System.out.println("잔고에 " + amount + "원을 입금하였습니다.\n" + "입금 후 금액 : " + balance + "원\n-------------------"  );
	}
}
