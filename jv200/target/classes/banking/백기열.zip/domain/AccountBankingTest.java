package banking.domain;

public class AccountBankingTest {
	public static void main(String[] args) {
		SavingsAccount savingAccount = new SavingsAccount();
		savingAccount.deposite(5000);
		savingAccount.setInteresRate(10);
		savingAccount.withdraw(1000);
		
		CheckingAccount checkingAccount = new CheckingAccount();
		checkingAccount.deposite(1000);
		checkingAccount.setOverdraftAmount(2000);
		checkingAccount.withdraw(4000);
		
	}
}
